document.addEventListener('DOMContentLoaded',()=>{
const burger=document.getElementById('burger');const links=document.getElementById('navLinks');
if(burger)burger.addEventListener('click',()=>links.classList.toggle('show'));
});