Ristorante Orient Express — Modern Static Website
----------------------------------------------------
This site uses clean /page/index.html URLs.

To view locally:
  1. Extract the ZIP.
  2. Open index.html in your browser.

To deploy:
  Upload the folder to your web server or any static host (Netlify, Vercel, etc.).
