
Modernized website built from the uploaded lavanderia_full.txt
Files included:
- index.html, prezzi.html, la-card.html, media.html, istruzioni.html, contatti.html
- css/styles.css
- assets/images/* (SVG placeholders for original JPGs referenced in the source)
Place this folder on any static web host (GitHub Pages, Netlify, simple Apache/nginx) to preview.
